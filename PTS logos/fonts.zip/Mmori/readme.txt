Momento Mori v1.0
----------------------------------
A freeware font by John Flickinger
http://www.webdesignfire.com
webdesignfire@gmail.com
----------------------------------

This package includes:
----------------------
mmori.ttf
mmori_o.ttf
This readme.txt


USAGE
-----

This is a display typeface intended for LARGE titles and looks it's best around 96pt.

This font is free for personal or commercial use. You may use it freely, add it to your website, or distribute it in any digital format you wish for free as long as it includes the files listed above unaltered in any way. If you do use this font in a commercial project, or add it to a site, I would appreciate an e-mail showing me how it was used but you're not required to notify me. I'm not sure if I'll make another font soon, but if this one gets a positive response I probably will, so let me know if you do like it. 

In the future there may be newer versions of this font.